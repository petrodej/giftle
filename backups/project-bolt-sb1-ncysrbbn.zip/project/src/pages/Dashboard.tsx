import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import type { GiftProject } from '../types/database';
import { format, isAfter } from 'date-fns';
import LoadingScreen from '../components/LoadingScreen';
import UpcomingProjects from '../components/UpcomingProjects';

interface ProjectWithRole extends GiftProject {
  role: 'admin' | 'member';
}

export default function Dashboard() {
  const { user } = useAuth();
  const [projects, setProjects] = useState<ProjectWithRole[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadProjects() {
      if (!user?.email) return;

      try {
        // Get all projects where user is a member (by email or user_id)
        const { data: memberProjects, error: memberError } = await supabase
          .from('project_members')
          .select(`
            project_id,
            role,
            status,
            gift_projects (*)
          `)
          .eq('status', 'active')
          .or(`email.eq.${user.email},user_id.eq.${user.id}`);

        if (memberError) throw memberError;

        // Get all projects where user is creator
        const { data: createdProjects, error: creatorError } = await supabase
          .from('gift_projects')
          .select('*')
          .eq('created_by', user.id);

        if (creatorError) throw creatorError;

        // Combine and deduplicate projects
        const memberProjectsFormatted = (memberProjects || [])
          .filter(mp => mp.gift_projects) // Filter out any null projects
          .map(mp => ({
            ...mp.gift_projects,
            role: mp.role as 'admin' | 'member'
          }));

        const createdProjectsFormatted = (createdProjects || []).map(project => ({
          ...project,
          role: 'admin' as const
        }));

        // Combine projects, preferring created projects over member projects
        const projectMap = new Map<string, ProjectWithRole>();
        
        // Add member projects first
        memberProjectsFormatted.forEach(project => {
          if (project.id) {
            projectMap.set(project.id, project);
          }
        });

        // Override with created projects (as admin)
        createdProjectsFormatted.forEach(project => {
          if (project.id) {
            projectMap.set(project.id, project);
          }
        });

        setProjects(Array.from(projectMap.values()));
      } catch (error) {
        console.error('Error loading projects:', error);
      } finally {
        setLoading(false);
      }
    }

    loadProjects();
  }, [user]);

  const getStatusBadge = (project: ProjectWithRole) => {
    if (project.status === 'completed') {
      return {
        text: 'Completed',
        className: 'bg-gray-100 text-gray-800'
      };
    }
    if (project.voting_closed) {
      return {
        text: 'Voting Closed',
        className: 'bg-yellow-100 text-yellow-800'
      };
    }
    return {
      text: 'Active',
      className: 'bg-green-100 text-green-800'
    };
  };

  const getRoleBadge = (role: 'admin' | 'member') => {
    if (role === 'admin') {
      return {
        text: 'Admin',
        className: 'bg-indigo-100 text-indigo-800'
      };
    }
    return {
      text: 'Member',
      className: 'bg-blue-100 text-blue-800'
    };
  };

  // Filter projects to show
  const filteredProjects = projects.filter(project => {
    // For recurring projects:
    // Only show if it's a parent project or if its parent is completed
    if (project.is_recurring && project.parent_project_id) {
      const parentProject = projects.find(p => p.id === project.parent_project_id);
      return parentProject?.status === 'completed' && 
             isAfter(new Date(project.project_date), new Date());
    }
    // Show all non-recurring projects
    return true;
  });

  if (loading) {
    return <LoadingScreen message="Loading your gift projects..." />;
  }

  return (
    <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
      <div className="px-4 py-6 sm:px-0">
        <div className="flex justify-between items-center mb-6">
          <h1 className="text-2xl font-semibold text-gray-900">Your Gift Projects</h1>
          <Link
            to="/projects/new"
            className="bg-indigo-600 text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-indigo-500"
          >
            New Project
          </Link>
        </div>

        <div className="lg:grid lg:grid-cols-3 lg:gap-8">
          <div className="lg:col-span-2">
            {filteredProjects.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-lg shadow">
                <h3 className="mt-2 text-sm font-semibold text-gray-900">No gift projects</h3>
                <p className="mt-1 text-sm text-gray-500">Get started by creating a new gift project.</p>
                <div className="mt-6">
                  <Link
                    to="/projects/new"
                    className="inline-flex items-center rounded-md bg-indigo-600 px-3 py-2 text-sm font-semibold text-white shadow-sm hover:bg-indigo-500"
                  >
                    Create new project
                  </Link>
                </div>
              </div>
            ) : (
              <div className="grid gap-6 md:grid-cols-2">
                {filteredProjects.map((project) => {
                  const status = getStatusBadge(project);
                  const role = getRoleBadge(project.role);
                  return (
                    <Link
                      key={project.id}
                      to={`/projects/${project.id}`}
                      className="block p-6 bg-white rounded-lg border border-gray-200 hover:shadow-md transition-shadow"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <h5 className="text-xl font-bold tracking-tight text-gray-900">
                          Gift for {project.recipient_name}
                        </h5>
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${role.className}`}
                        >
                          {role.text}
                        </span>
                      </div>
                      <p className="text-sm text-gray-600">
                        Date: {format(new Date(project.project_date), 'MMM d, yyyy')}
                      </p>
                      {project.interests && project.interests.length > 0 && (
                        <div className="mt-2">
                          <p className="text-sm text-gray-500">Interests:</p>
                          <div className="flex flex-wrap gap-2 mt-1">
                            {project.interests.map((interest, index) => (
                              <span
                                key={index}
                                className="px-2 py-1 text-xs font-medium bg-gray-100 rounded-full text-gray-600"
                              >
                                {interest}
                              </span>
                            ))}
                          </div>
                        </div>
                      )}
                      <div className="mt-4">
                        <span
                          className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${status.className}`}
                        >
                          {status.text}
                        </span>
                      </div>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>

          <div className="mt-8 lg:mt-0">
            <UpcomingProjects projects={projects} />
          </div>
        </div>
      </div>
    </div>
  );
}