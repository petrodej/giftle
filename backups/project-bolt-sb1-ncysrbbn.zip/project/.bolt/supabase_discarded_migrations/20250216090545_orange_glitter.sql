-- Drop existing policies for project_members
DROP POLICY IF EXISTS "Insert members" ON project_members;
DROP POLICY IF EXISTS "Update members" ON project_members;

-- Create comprehensive policies for project members
CREATE POLICY "Manage members"
  ON project_members
  FOR ALL
  TO authenticated
  USING (
    -- Can access if:
    (
      -- It's their own membership (by email or user_id)
      email = auth.email()
      OR user_id = auth.uid()
      OR
      -- Or they're the project creator
      EXISTS (
        SELECT 1 
        FROM gift_projects 
        WHERE id = project_id 
        AND created_by = auth.uid()
      )
    )
  )
  WITH CHECK (
    -- Can modify if:
    (
      -- It's their own membership (by email or user_id)
      email = auth.email()
      OR user_id = auth.uid()
      OR
      -- Or they're the project creator
      EXISTS (
        SELECT 1 
        FROM gift_projects 
        WHERE id = project_id 
        AND created_by = auth.uid()
      )
    )
  );

-- Create or replace the member trigger function
CREATE OR REPLACE FUNCTION handle_member_updates()
RETURNS TRIGGER AS $$
DECLARE
  _user_id uuid;
  _email text;
BEGIN
  -- Get current user info
  _user_id := auth.uid();
  _email := auth.email();

  -- When a user joins
  IF TG_OP = 'INSERT' THEN
    -- Always set email to the authenticated user's email if available
    IF _email IS NOT NULL THEN
      NEW.email := _email;
    END IF;

    -- If user is authenticated, set their user_id and make them active
    IF _user_id IS NOT NULL THEN
      NEW.user_id := _user_id;
      NEW.status := 'active';
    ELSE
      -- For email-only invites, set as pending
      NEW.status := COALESCE(NEW.status, 'pending');
    END IF;
  END IF;

  -- When updating an existing member
  IF TG_OP = 'UPDATE' THEN
    -- If user_id is being set and was previously NULL
    IF NEW.user_id IS NOT NULL AND OLD.user_id IS NULL THEN
      -- Activate the membership and ensure email matches
      NEW.status := 'active';
      -- Update email if it was a pending invitation
      IF OLD.status = 'pending' AND _email IS NOT NULL THEN
        NEW.email := _email;
      END IF;
    END IF;
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Recreate the trigger
DROP TRIGGER IF EXISTS member_updates ON project_members;
CREATE TRIGGER member_updates
  BEFORE INSERT OR UPDATE ON project_members
  FOR EACH ROW
  EXECUTE FUNCTION handle_member_updates();

-- Grant necessary permissions
GRANT ALL ON project_members TO authenticated;